/**************************************************************************/
/*  Dictionary.java                                                       */
/**************************************************************************/
/*                         This file is part of:                          */
/*                             GODOT ENGINE                               */
/*                        https://godotengine.org                         */
/**************************************************************************/
/* Copyright (c) 2014-present Godot Engine contributors (see AUTHORS.md). */
/* Copyright (c) 2007-2014 Juan Linietsky, Ariel Manzur.                  */
/*                                                                        */
/* Permission is hereby granted, free of charge, to any person obtaining  */
/* a copy of this software and associated documentation files (the        */
/* "Software"), to deal in the Software without restriction, including    */
/* without limitation the rights to use, copy, modify, merge, publish,    */
/* distribute, sublicense, and/or sell copies of the Software, and to     */
/* permit persons to whom the Software is furnished to do so, subject to  */
/* the following conditions:                                              */
/*                                                                        */
/* The above copyright notice and this permission notice shall be         */
/* included in all copies or substantial portions of the Software.        */
/*                                                                        */
/* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,        */
/* EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF     */
/* MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. */
/* IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY   */
/* CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT,   */
/* TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE      */
/* SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.                 */
/**************************************************************************/

package org.godotengine.godot;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public final class Dictionary extends HashMap<String, Object> {
	private String[] keys_cache;

	/**
	 * @deprecated Use {@link java.util.HashMap#keySet()} instead.
	 */
	@Deprecated
	public String[] get_keys() {
		String[] ret = new String[size()];
		int i = 0;
		Set<String> keys = keySet();
		for (String key : keys) {
			ret[i] = key;
			i++;
		}

		return ret;
	}

	/**
	 * @deprecated Use {@link java.util.HashMap#values()} instead.
	 */
	@Deprecated
	public Object[] get_values() {
		Object[] ret = new Object[size()];
		int i = 0;
		Set<String> keys = keySet();
		for (String key : keys) {
			ret[i] = get(key);
			i++;
		}

		return ret;
	}

	/**
	 * @deprecated Use {@link java.util.HashMap#putAll(Map)} instead.
	 */
	@Deprecated
	public void set_keys(String[] keys) {
		keys_cache = keys;
	}

	/**
	 * @deprecated Use {@link java.util.HashMap#putAll(Map)} instead.
	 */
	@Deprecated
	public void set_values(Object[] vals) {
		int i = 0;
		for (String key : keys_cache) {
			put(key, vals[i]);
			i++;
		}
		keys_cache = null;
	}
}
